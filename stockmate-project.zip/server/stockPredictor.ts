import * as tf from '@tensorflow/tfjs-node';
import { StockDataResponse, PredictionResponse } from '@shared/schema';
import { COMPANIES } from '../client/src/lib/constants';

// Window size for LSTM model (number of previous data points to consider)
const WINDOW_SIZE = 12; // Further reduced from 20 for faster performance
// Training ratio - percentage of data to use for training
const TRAINING_RATIO = 0.75; // Reduced training data ratio for faster performance
// Sampling stride to reduce data points by taking every Nth point
const SAMPLING_STRIDE = 3; // Sample every 3rd data point to reduce computation

// Cache for predictions to avoid recomputing
interface PredictionCache {
  [key: string]: {
    prediction: PredictionResponse;
    timestamp: number;
    params: {
      symbol: string;
      startDate: string;
      endDate: string;
    };
  };
}

// In-memory cache with 30-minute expiration
const predictionCache: PredictionCache = {};
// Cache hit counter for logging
let cacheHits = 0;
let cacheMisses = 0;

// Scale data between 0 and 1 (faster min-max normalization)
function scaleData(data: number[]): { scaledData: number[], scaler: { min: number, max: number } } {
  // Use faster approach to find min and max
  let min = data[0];
  let max = data[0];
  
  for (let i = 1; i < data.length; i++) {
    if (data[i] < min) min = data[i];
    if (data[i] > max) max = data[i];
  }
  
  // Only compute range once
  const range = max - min;
  const scaledData = data.map(value => (value - min) / range);
  
  return {
    scaledData,
    scaler: { min, max }
  };
}

// Inverse scale to get back original values (faster implementation)
function inverseScale(
  scaledValue: number, 
  scaler: { min: number, max: number }
): number {
  const range = scaler.max - scaler.min;
  return scaledValue * range + scaler.min;
}

// Create sequences for LSTM model (optimized version)
function createSequences(
  data: number[], 
  windowSize: number
): { x: number[][], y: number[] } {
  const length = data.length - windowSize;
  const x: number[][] = new Array(length);
  const y: number[] = new Array(length);
  
  for (let i = 0; i < length; i++) {
    // Reuse the same slice for each window to avoid creating many arrays
    x[i] = data.slice(i, i + windowSize);
    y[i] = data[i + windowSize];
  }
  
  return { x, y };
}

// Calculate Mean Squared Error (optimized)
function calculateMSE(actual: number[], predicted: number[]): number {
  if (actual.length !== predicted.length || actual.length === 0) {
    return 0;
  }
  
  let sumSquaredError = 0;
  for (let i = 0; i < actual.length; i++) {
    const error = actual[i] - predicted[i];
    sumSquaredError += error * error;
  }
  
  return sumSquaredError / actual.length;
}

// Build and train LSTM model (optimized for speed)
async function buildAndTrainModel(trainX: number[][], trainY: number[]): Promise<tf.LayersModel> {
  // Create sequential model
  const model = tf.sequential();
  
  // Ultra-simplified model architecture for fastest training
  model.add(tf.layers.lstm({
    units: 8, // Reduced from 16 for faster performance
    returnSequences: false,
    inputShape: [trainX[0].length, 1]
  }));
  
  // Single dense layer
  model.add(tf.layers.dense({
    units: 1
  }));
  
  // Compile model with fastest optimizer
  model.compile({
    optimizer: tf.train.adam(0.01), // Using Adam with higher learning rate for faster convergence
    loss: 'meanSquaredError'
  });
  
  // Prepare tensors more efficiently
  const reshapedTrainX = trainX.map(seq => seq.map(val => [val]));
  const tensorTrainX = tf.tensor3d(reshapedTrainX);
  const tensorTrainY = tf.tensor2d(trainY.map(val => [val]));
  
  // Train with minimal epochs and largest batch size for max speed
  await model.fit(tensorTrainX, tensorTrainY, {
    epochs: 2, // Minimum epochs needed for acceptable results
    batchSize: 128, // Larger batch size for faster training
    shuffle: true,
    verbose: 0
  });
  
  // Clean up tensors
  tensorTrainX.dispose();
  tensorTrainY.dispose();
  
  return model;
}

// Make predictions using the trained model (optimized)
function predict(
  model: tf.LayersModel, 
  testX: number[][], 
  scaler: { min: number, max: number }
): number[] {
  // Reshape and create tensor in one step
  const reshapedTestX = testX.map(seq => seq.map(val => [val]));
  const tensorTestX = tf.tensor3d(reshapedTestX);
  
  // Make predictions in a single tensor operation
  const tensorPredictions = model.predict(tensorTestX) as tf.Tensor;
  const scaledPredictions = tensorPredictions.dataSync();
  
  // Preallocate results array for better performance
  const predictions = new Array(scaledPredictions.length);
  const range = scaler.max - scaler.min;
  
  // Faster inverse scaling with precomputed range
  for (let i = 0; i < scaledPredictions.length; i++) {
    predictions[i] = scaledPredictions[i] * range + scaler.min;
  }
  
  // Clean up tensors
  tensorTestX.dispose();
  tensorPredictions.dispose();
  
  return predictions;
}

// Main prediction function with optimizations
export async function predictStockPrice(stockData: StockDataResponse): Promise<PredictionResponse> {
  const { symbol, name, data } = stockData;
  
  // Generate cache key using symbol and data range
  const startDate = data[0]?.date || '';
  const endDate = data[data.length - 1]?.date || '';
  const cacheKey = `${symbol}_${startDate}_${endDate}`;
  
  // Check if we have a valid cached prediction (now with 30-minute expiration)
  const cachedResult = predictionCache[cacheKey];
  const now = Date.now();
  const cacheExpiryTime = 30 * 60 * 1000; // 30 minutes in milliseconds for longer cache validity
  
  if (cachedResult && (now - cachedResult.timestamp) < cacheExpiryTime) {
    console.log(`Using cached prediction for ${symbol} (cache hit #${++cacheHits})`);
    return cachedResult.prediction;
  }
  
  // If no valid cache, generate a new prediction
  console.log(`Generating new prediction for ${symbol} (cache miss #${++cacheMisses})`);
  console.time('Prediction generation time');
  
  // Sample data with stride to reduce computation while maintaining pattern
  const sampledData = [];
  const sampledDates = [];
  
  for (let i = 0; i < data.length; i += SAMPLING_STRIDE) {
    sampledData.push(data[i]);
    sampledDates.push(data[i].date);
  }
  
  // Extract close prices from sampled data
  const closePrices = sampledData.map(item => item.close);
  const dates = sampledDates;
  
  console.log(`Data reduced from ${data.length} to ${closePrices.length} points using sampling stride of ${SAMPLING_STRIDE}`);
  
  // Scale the data
  const { scaledData, scaler } = scaleData(closePrices);
  
  // Split data into training and testing sets
  const trainingSize = Math.floor(closePrices.length * TRAINING_RATIO);
  const trainData = scaledData.slice(0, trainingSize);
  
  // Create sequences more efficiently
  console.time('Sequence creation time');
  const { x: trainX, y: trainY } = createSequences(trainData, WINDOW_SIZE);
  console.timeEnd('Sequence creation time');
  
  // Build and train model
  console.time('Model training time');
  const model = await buildAndTrainModel(trainX, trainY);
  console.timeEnd('Model training time');
  
  // Prepare test data more efficiently
  console.time('Prediction time');
  const testData = scaledData.slice(trainingSize - WINDOW_SIZE);
  
  // Preallocate test array
  const testSize = testData.length - WINDOW_SIZE;
  const testX = new Array(testSize);
  
  // Create test sequences
  for (let i = 0; i < testSize; i++) {
    testX[i] = testData.slice(i, i + WINDOW_SIZE);
  }
  
  // Make predictions
  const scaledPredictions = predict(model, testX, scaler);
  console.timeEnd('Prediction time');
  
  // Actual values for comparison
  const actualValues = closePrices.slice(trainingSize);
  
  // Calculate metrics
  const mse = calculateMSE(actualValues, scaledPredictions);
  const rmse = Math.sqrt(mse);
  const accuracy = 100 - (rmse / (scaler.max - scaler.min) * 100);
  
  // Prepare response data more efficiently
  // Only use a subset of points for visualization to improve frontend performance
  const maxPointsToReturn = 100; // Limit points for better frontend rendering
  
  const trainingDataStep = Math.max(1, Math.floor(trainingSize / maxPointsToReturn));
  const trainingData = [];
  for (let i = 0; i < trainingSize; i += trainingDataStep) {
    trainingData.push({
      date: dates[i],
      value: closePrices[i]
    });
  }
  
  const testingStep = Math.max(1, Math.floor(actualValues.length / maxPointsToReturn));
  const testingData = [];
  for (let i = 0; i < actualValues.length; i += testingStep) {
    testingData.push({
      date: dates[trainingSize + i],
      value: actualValues[i]
    });
  }
  
  const predictionsStep = Math.max(1, Math.floor(scaledPredictions.length / maxPointsToReturn));
  const predictions = [];
  for (let i = 0; i < scaledPredictions.length; i += predictionsStep) {
    predictions.push({
      date: dates[trainingSize + i],
      value: scaledPredictions[i]
    });
  }
  
  // Get current price and change percent
  const currentPrice = closePrices[closePrices.length - 1];
  const previousPrice = closePrices[closePrices.length - 2] || currentPrice;
  const changePercent = ((currentPrice - previousPrice) / previousPrice) * 100;
  
  // Create prediction response
  const prediction = {
    symbol,
    name,
    currentPrice,
    changePercent,
    trainingData,
    testingData,
    predictions,
    metrics: {
      mse,
      rmse,
      accuracy
    }
  };
  
  // Cache the result
  predictionCache[cacheKey] = {
    prediction,
    timestamp: now,
    params: {
      symbol,
      startDate,
      endDate
    }
  };
  
  // Track cache size for memory management
  const cacheSize = Object.keys(predictionCache).length;
  if (cacheSize % 10 === 0) {
    console.log(`Cache size: ${cacheSize} predictions`);
  }
  
  console.timeEnd('Prediction generation time');
  return prediction;
}
