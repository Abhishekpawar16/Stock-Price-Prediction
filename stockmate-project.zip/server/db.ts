import { drizzle } from 'drizzle-orm/node-postgres';
import pg from 'pg';
import * as schema from '@shared/schema';

const { Pool } = pg;

// Get database connection string from environment variables
const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
  console.error('DATABASE_URL environment variable is not set');
  process.exit(1);
}

// Create PostgreSQL pool for better connection management
const pool = new Pool({
  connectionString,
  max: 10, // Maximum number of clients in the pool
  idleTimeoutMillis: 30000, // How long a client is allowed to remain idle before being closed
});

// Test the pool connection
async function connectToDatabase() {
  let testClient;
  try {
    testClient = await pool.connect();
    console.log('Connected to PostgreSQL database');
    return true;
  } catch (error) {
    console.error('Failed to connect to PostgreSQL database:', error);
    return false;
  } finally {
    // Release the client back to the pool
    if (testClient) testClient.release();
  }
}

// Initialize connection test
connectToDatabase();

// Create and export a Drizzle ORM instance using the pool
export const db = drizzle(pool, { schema });

// Function to close the pool
export const closeConnection = async () => {
  try {
    await pool.end();
    console.log('Database connection pool closed');
  } catch (error) {
    console.error('Error closing database connection pool:', error);
  }
};

// Handle application shutdown
process.on('SIGINT', async () => {
  console.log('Closing database connection due to application shutdown');
  await closeConnection();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  console.log('Closing database connection due to application termination');
  await closeConnection();
  process.exit(0);
});