import { db } from '../db';
import { stockPrices, insertStockPriceSchema, type InsertStockPrice, type StockPrice } from '@shared/schema';
import { eq, and, gte, lte, desc, sql } from 'drizzle-orm';
import { getCompanyBySymbol } from './companyService';

// Get stock prices for a company within a date range
export async function getStockPricesByCompanyId(
  companyId: number,
  startDate?: string,
  endDate?: string
): Promise<StockPrice[]> {
  try {
    let conditions = [eq(stockPrices.companyId, companyId)];
    
    if (startDate) {
      conditions.push(gte(stockPrices.date, startDate));
    }
    
    if (endDate) {
      conditions.push(lte(stockPrices.date, endDate));
    }
    
    let query = db.select().from(stockPrices).where(and(...conditions));
    
    return await query.orderBy(stockPrices.date);
  } catch (error) {
    console.error(`Error getting stock prices for company ID ${companyId}:`, error);
    return [];
  }
}

// Get stock prices for a company by symbol
export async function getStockPricesBySymbol(
  symbol: string,
  startDate?: string,
  endDate?: string
): Promise<StockPrice[]> {
  try {
    const company = await getCompanyBySymbol(symbol);
    if (!company) {
      console.error(`Company with symbol ${symbol} not found`);
      return [];
    }
    
    return await getStockPricesByCompanyId(company.id, startDate, endDate);
  } catch (error) {
    console.error(`Error getting stock prices for symbol ${symbol}:`, error);
    return [];
  }
}

// Add a single stock price record
export async function addStockPrice(data: InsertStockPrice): Promise<StockPrice | null> {
  try {
    const validated = insertStockPriceSchema.parse(data);
    const results = await db.insert(stockPrices).values(validated).returning();
    return results.length > 0 ? results[0] : null;
  } catch (error) {
    console.error('Error adding stock price:', error);
    return null;
  }
}

// Add multiple stock price records efficiently
export async function addStockPrices(data: InsertStockPrice[]): Promise<number> {
  try {
    if (data.length === 0) {
      return 0;
    }
    
    const results = await db.insert(stockPrices).values(data).returning();
    return results.length;
  } catch (error) {
    console.error('Error adding multiple stock prices:', error);
    return 0;
  }
}

// Delete stock prices for a company
export async function deleteStockPricesForCompany(companyId: number): Promise<number> {
  try {
    const results = await db.delete(stockPrices)
      .where(eq(stockPrices.companyId, companyId))
      .returning();
    return results.length;
  } catch (error) {
    console.error(`Error deleting stock prices for company ID ${companyId}:`, error);
    return 0;
  }
}

// Get the latest stock price for a company
export async function getLatestStockPrice(companyId: number): Promise<StockPrice | null> {
  try {
    const results = await db.select()
      .from(stockPrices)
      .where(eq(stockPrices.companyId, companyId))
      .orderBy(desc(stockPrices.date))
      .limit(1);
    
    return results.length > 0 ? results[0] : null;
  } catch (error) {
    console.error(`Error getting latest stock price for company ID ${companyId}:`, error);
    return null;
  }
}

// Get stock prices for multiple companies
export async function getStockPricesForCompanies(
  companyIds: number[],
  limit: number = 30
): Promise<{[companyId: number]: StockPrice[]}> {
  try {
    if (companyIds.length === 0) {
      return {};
    }
    
    const results: {[companyId: number]: StockPrice[]} = {};
    
    for (const companyId of companyIds) {
      const prices = await db.select()
        .from(stockPrices)
        .where(eq(stockPrices.companyId, companyId))
        .orderBy(desc(stockPrices.date))
        .limit(limit);
      
      results[companyId] = prices.reverse(); // Reverse to get chronological order
    }
    
    return results;
  } catch (error) {
    console.error('Error getting stock prices for multiple companies:', error);
    return {};
  }
}

// Calculate simple metrics for a company's stock
export async function calculateStockMetrics(companyId: number, days: number = 30): Promise<any> {
  try {
    const prices = await db.select()
      .from(stockPrices)
      .where(eq(stockPrices.companyId, companyId))
      .orderBy(desc(stockPrices.date))
      .limit(days);
    
    if (prices.length === 0) {
      return null;
    }
    
    const latestPrice = prices[0];
    const previousPrice = prices.length > 1 ? prices[1] : null;
    
    // Calculate change percentage
    const changePercent = previousPrice 
      ? ((Number(latestPrice.close) - Number(previousPrice.close)) / Number(previousPrice.close)) * 100 
      : 0;
    
    // Calculate average volume
    const avgVolume = prices.reduce((sum, price) => sum + price.volume, 0) / prices.length;
    
    // Calculate high and low
    const high = Math.max(...prices.map(price => Number(price.high)));
    const low = Math.min(...prices.map(price => Number(price.low)));
    
    return {
      currentPrice: latestPrice.close,
      changePercent,
      avgVolume,
      high,
      low,
      latestDate: latestPrice.date
    };
  } catch (error) {
    console.error(`Error calculating metrics for company ID ${companyId}:`, error);
    return null;
  }
}