import { db } from '../db';
import { companies, insertCompanySchema, type InsertCompany, type Company } from '@shared/schema';
import { eq } from 'drizzle-orm';
import { COMPANIES } from '../../client/src/lib/constants';

// Get all companies
export async function getAllCompanies(): Promise<Company[]> {
  try {
    return await db.select().from(companies);
  } catch (error) {
    console.error('Error getting all companies:', error);
    return [];
  }
}

// Get company by symbol
export async function getCompanyBySymbol(symbol: string): Promise<Company | null> {
  try {
    const results = await db.select().from(companies).where(eq(companies.symbol, symbol));
    return results.length > 0 ? results[0] : null;
  } catch (error) {
    console.error(`Error getting company with symbol ${symbol}:`, error);
    return null;
  }
}

// Create a new company
export async function createCompany(data: InsertCompany): Promise<Company | null> {
  try {
    const validated = insertCompanySchema.parse(data);
    const results = await db.insert(companies).values(validated).returning();
    return results.length > 0 ? results[0] : null;
  } catch (error) {
    console.error('Error creating company:', error);
    return null;
  }
}

// Update an existing company
export async function updateCompany(id: number, data: Partial<InsertCompany>): Promise<Company | null> {
  try {
    const results = await db.update(companies)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(companies.id, id))
      .returning();
    return results.length > 0 ? results[0] : null;
  } catch (error) {
    console.error(`Error updating company with id ${id}:`, error);
    return null;
  }
}

// Delete a company
export async function deleteCompany(id: number): Promise<boolean> {
  try {
    const results = await db.delete(companies)
      .where(eq(companies.id, id))
      .returning();
    return results.length > 0;
  } catch (error) {
    console.error(`Error deleting company with id ${id}:`, error);
    return false;
  }
}

// Seed company data from constants
export async function seedCompanies(): Promise<void> {
  try {
    console.log('Seeding company data...');
    
    // Get existing companies
    const existingCompanies = await getAllCompanies();
    const existingSymbols = new Set(existingCompanies.map(company => company.symbol));
    
    // Filter out companies that already exist
    const companiesToCreate = COMPANIES.filter(company => !existingSymbols.has(company.symbol));
    
    if (companiesToCreate.length === 0) {
      console.log('All companies already exist in database');
      return;
    }
    
    // Prepare company data for insertion
    const companyData: InsertCompany[] = companiesToCreate.map(company => ({
      symbol: company.symbol,
      name: company.name,
      description: `${company.name} is a publicly traded company.`,
      logo: company.logo || null
    }));
    
    // Insert companies in batches
    await Promise.all(companyData.map(createCompany));
    
    console.log(`Seeded ${companyData.length} companies`);
  } catch (error) {
    console.error('Error seeding companies:', error);
  }
}