import { db } from '../db';
import { 
  watchlists, 
  watchlistItems, 
  companies,
  insertWatchlistSchema, 
  insertWatchlistItemSchema,
  type InsertWatchlist,
  type InsertWatchlistItem, 
  type Watchlist,
  type WatchlistItem,
  type Company
} from '@shared/schema';
import { eq, and } from 'drizzle-orm';
import { getCompanyBySymbol } from './companyService';

// Get watchlists for a user
export async function getWatchlistsByUserId(userId: number): Promise<Watchlist[]> {
  try {
    return await db.select()
      .from(watchlists)
      .where(eq(watchlists.userId, userId));
  } catch (error) {
    console.error(`Error getting watchlists for user ID ${userId}:`, error);
    return [];
  }
}

// Create a new watchlist
export async function createWatchlist(data: InsertWatchlist): Promise<Watchlist | null> {
  try {
    const validated = insertWatchlistSchema.parse(data);
    const results = await db.insert(watchlists).values(validated).returning();
    return results.length > 0 ? results[0] : null;
  } catch (error) {
    console.error('Error creating watchlist:', error);
    return null;
  }
}

// Get a watchlist by ID
export async function getWatchlistById(id: number): Promise<Watchlist | null> {
  try {
    const results = await db.select()
      .from(watchlists)
      .where(eq(watchlists.id, id));
    
    return results.length > 0 ? results[0] : null;
  } catch (error) {
    console.error(`Error getting watchlist with ID ${id}:`, error);
    return null;
  }
}

// Delete a watchlist
export async function deleteWatchlist(id: number): Promise<boolean> {
  try {
    // First delete all items in the watchlist
    await db.delete(watchlistItems)
      .where(eq(watchlistItems.watchlistId, id));
    
    // Then delete the watchlist itself
    const results = await db.delete(watchlists)
      .where(eq(watchlists.id, id))
      .returning();
    
    return results.length > 0;
  } catch (error) {
    console.error(`Error deleting watchlist with ID ${id}:`, error);
    return false;
  }
}

// Get all items in a watchlist
export async function getWatchlistItems(watchlistId: number): Promise<WatchlistItem[]> {
  try {
    return await db.select()
      .from(watchlistItems)
      .where(eq(watchlistItems.watchlistId, watchlistId));
  } catch (error) {
    console.error(`Error getting items for watchlist ID ${watchlistId}:`, error);
    return [];
  }
}

// Get all companies in a watchlist
export async function getWatchlistCompanies(watchlistId: number): Promise<Company[]> {
  try {
    return await db.select({
      id: companies.id,
      symbol: companies.symbol,
      name: companies.name,
      description: companies.description,
      industry: companies.industry,
      sector: companies.sector,
      logo: companies.logo,
      website: companies.website,
      ceo: companies.ceo,
      employees: companies.employees,
      marketCap: companies.marketCap,
      peRatio: companies.peRatio,
      dividendYield: companies.dividendYield,
      createdAt: companies.createdAt,
      updatedAt: companies.updatedAt
    })
    .from(watchlistItems)
    .innerJoin(companies, eq(watchlistItems.companyId, companies.id))
    .where(eq(watchlistItems.watchlistId, watchlistId));
  } catch (error) {
    console.error(`Error getting companies for watchlist ID ${watchlistId}:`, error);
    return [];
  }
}

// Add a company to a watchlist
export async function addCompanyToWatchlist(
  watchlistId: number,
  companyId: number
): Promise<WatchlistItem | null> {
  try {
    // Check if the item already exists
    const existing = await db.select()
      .from(watchlistItems)
      .where(
        and(
          eq(watchlistItems.watchlistId, watchlistId),
          eq(watchlistItems.companyId, companyId)
        )
      );
    
    if (existing.length > 0) {
      return existing[0];
    }
    
    const data: InsertWatchlistItem = {
      watchlistId,
      companyId
    };
    
    const validated = insertWatchlistItemSchema.parse(data);
    const results = await db.insert(watchlistItems).values(validated).returning();
    return results.length > 0 ? results[0] : null;
  } catch (error) {
    console.error(`Error adding company ${companyId} to watchlist ${watchlistId}:`, error);
    return null;
  }
}

// Add a company to a watchlist by symbol
export async function addCompanyToWatchlistBySymbol(
  watchlistId: number,
  symbol: string
): Promise<WatchlistItem | null> {
  try {
    const company = await getCompanyBySymbol(symbol);
    if (!company) {
      console.error(`Company with symbol ${symbol} not found`);
      return null;
    }
    
    return await addCompanyToWatchlist(watchlistId, company.id);
  } catch (error) {
    console.error(`Error adding company ${symbol} to watchlist ${watchlistId}:`, error);
    return null;
  }
}

// Remove a company from a watchlist
export async function removeCompanyFromWatchlist(
  watchlistId: number,
  companyId: number
): Promise<boolean> {
  try {
    const results = await db.delete(watchlistItems)
      .where(
        and(
          eq(watchlistItems.watchlistId, watchlistId),
          eq(watchlistItems.companyId, companyId)
        )
      )
      .returning();
    
    return results.length > 0;
  } catch (error) {
    console.error(`Error removing company ${companyId} from watchlist ${watchlistId}:`, error);
    return false;
  }
}

// Get or create a default watchlist for a user
export async function getOrCreateDefaultWatchlist(userId: number): Promise<Watchlist> {
  try {
    // Try to find an existing default watchlist
    const existingWatchlists = await db.select()
      .from(watchlists)
      .where(eq(watchlists.userId, userId));
    
    if (existingWatchlists.length > 0) {
      return existingWatchlists[0];
    }
    
    // Create a new default watchlist
    const data: InsertWatchlist = {
      userId,
      name: 'My Watchlist'
    };
    
    const result = await createWatchlist(data);
    if (!result) {
      throw new Error(`Failed to create default watchlist for user ${userId}`);
    }
    
    return result;
  } catch (error) {
    console.error(`Error getting or creating default watchlist for user ${userId}:`, error);
    throw error;
  }
}