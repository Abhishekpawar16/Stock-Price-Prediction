import { db } from '../db';
import { predictions, insertPredictionSchema, type InsertPrediction, type Prediction } from '@shared/schema';
import { eq, and, gte, lte, desc } from 'drizzle-orm';
import { getCompanyBySymbol } from './companyService';

// Get predictions for a company
export async function getPredictionsByCompanyId(companyId: number): Promise<Prediction[]> {
  try {
    return await db.select()
      .from(predictions)
      .where(eq(predictions.companyId, companyId))
      .orderBy(desc(predictions.predictionDate));
  } catch (error) {
    console.error(`Error getting predictions for company ID ${companyId}:`, error);
    return [];
  }
}

// Get predictions for a company by symbol
export async function getPredictionsBySymbol(symbol: string): Promise<Prediction[]> {
  try {
    const company = await getCompanyBySymbol(symbol);
    if (!company) {
      console.error(`Company with symbol ${symbol} not found`);
      return [];
    }
    
    return await getPredictionsByCompanyId(company.id);
  } catch (error) {
    console.error(`Error getting predictions for symbol ${symbol}:`, error);
    return [];
  }
}

// Add a prediction
export async function addPrediction(data: InsertPrediction): Promise<Prediction | null> {
  try {
    const validated = insertPredictionSchema.parse(data);
    const results = await db.insert(predictions).values(validated).returning();
    return results.length > 0 ? results[0] : null;
  } catch (error) {
    console.error('Error adding prediction:', error);
    return null;
  }
}

// Get latest prediction for a company
export async function getLatestPrediction(companyId: number): Promise<Prediction | null> {
  try {
    const results = await db.select()
      .from(predictions)
      .where(eq(predictions.companyId, companyId))
      .orderBy(desc(predictions.predictionDate))
      .limit(1);
    
    return results.length > 0 ? results[0] : null;
  } catch (error) {
    console.error(`Error getting latest prediction for company ID ${companyId}:`, error);
    return null;
  }
}

// Get prediction by ID
export async function getPredictionById(id: number): Promise<Prediction | null> {
  try {
    const results = await db.select()
      .from(predictions)
      .where(eq(predictions.id, id));
    
    return results.length > 0 ? results[0] : null;
  } catch (error) {
    console.error(`Error getting prediction with ID ${id}:`, error);
    return null;
  }
}

// Delete a prediction
export async function deletePrediction(id: number): Promise<boolean> {
  try {
    const results = await db.delete(predictions)
      .where(eq(predictions.id, id))
      .returning();
    
    return results.length > 0;
  } catch (error) {
    console.error(`Error deleting prediction with ID ${id}:`, error);
    return false;
  }
}

// Find a prediction by company and date range
export async function findPrediction(
  companyId: number,
  startDate: string,
  endDate: string
): Promise<Prediction | null> {
  try {
    const results = await db.select()
      .from(predictions)
      .where(
        and(
          eq(predictions.companyId, companyId),
          eq(predictions.startDate, startDate),
          eq(predictions.endDate, endDate)
        )
      )
      .orderBy(desc(predictions.predictionDate))
      .limit(1);
    
    return results.length > 0 ? results[0] : null;
  } catch (error) {
    console.error(`Error finding prediction for company ID ${companyId}:`, error);
    return null;
  }
}