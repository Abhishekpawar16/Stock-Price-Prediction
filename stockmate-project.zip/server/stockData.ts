import { StockDataResponse } from '@shared/schema';
import { COMPANIES } from '../client/src/lib/constants';

// In-memory cache for stock data
let stockDataCache: { [key: string]: any[] } = {};

// Generate synthetic data for testing - optimized for performance
async function generateSyntheticData() {
  if (Object.keys(stockDataCache).length > 0) {
    return stockDataCache;
  }

  console.time('Synthetic data generation');
  
  // Use a smaller date range for faster processing
  const startDate = new Date('2015-01-01'); // Changed from 2013 to 2015 (2 years less data)
  const endDate = new Date('2018-01-01');
  const dayDiff = Math.floor((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
  
  const groupedData: { [key: string]: any[] } = {};
  
  // Generate data for each company
  for (const company of COMPANIES) {
    const symbol = company.symbol;
    
    // Preallocate array with estimated size for better performance
    const estimatedSize = Math.ceil(dayDiff / 10); // Every 10 days
    groupedData[symbol] = new Array(estimatedSize);
    
    // Initial stock price between $50 and $500
    let currentPrice = 50 + Math.random() * 450;
    
    // Use an even smaller dataset (one entry per 10 days) for faster processing
    // This will give us ~100 data points (3 years) instead of 1095 (daily for 3 years)
    const stride = 10; // Every 10 days (further reduced from 5)
    
    let dataIndex = 0;
    
    // Generate data with stride
    for (let i = 0; i < dayDiff; i += stride) {
      const currentDate = new Date(startDate.getTime() + i * 24 * 60 * 60 * 1000);
      const dateStr = currentDate.toISOString().split('T')[0];
      
      // Daily volatility - random change between -5% and +5%
      const dailyChange = (Math.random() * 10 - 5) / 100;
      
      // Compute open, high, low, close
      const open = currentPrice;
      const close = open * (1 + dailyChange);
      const high = Math.max(open, close) * (1 + Math.random() * 0.02);
      const low = Math.min(open, close) * (1 - Math.random() * 0.02);
      
      // Volume between 1M and 20M
      const volume = Math.floor(1000000 + Math.random() * 19000000);
      
      // Precalculate fixed values for better performance
      const openFixed = parseFloat(open.toFixed(2));
      const highFixed = parseFloat(high.toFixed(2));
      const lowFixed = parseFloat(low.toFixed(2));
      const closeFixed = parseFloat(close.toFixed(2));
      
      // Store directly into preallocated array
      groupedData[symbol][dataIndex++] = {
        date: dateStr,
        open: openFixed,
        high: highFixed,
        low: lowFixed,
        close: closeFixed,
        volume: volume
      };
      
      // Set current price for next day
      currentPrice = close;
    }
    
    // Trim any unused array slots if our estimate was off
    if (dataIndex < estimatedSize) {
      groupedData[symbol].length = dataIndex;
    }
  }
  
  // Store in cache
  stockDataCache = groupedData;
  
  console.timeEnd('Synthetic data generation');
  console.log(`Generated stock data for ${COMPANIES.length} companies with ~${groupedData[COMPANIES[0].symbol].length} data points each`);
  
  return groupedData;
}

// Get all stock data
export async function getStockData(): Promise<{ [key: string]: any[] }> {
  return await generateSyntheticData();
}

// Get stock data for a specific symbol within a date range (optimized)
export async function getStockBySymbol(
  symbol: string,
  startDate: string = '2015-01-01', // Updated default to match our new data range
  endDate: string = '2018-01-01'
): Promise<StockDataResponse | null> {
  console.time(`Get stock data for ${symbol}`);
  const allStocks = await generateSyntheticData();
  
  if (!allStocks[symbol]) {
    console.timeEnd(`Get stock data for ${symbol}`);
    return null;
  }
  
  // Parse dates once
  const startTime = new Date(startDate).getTime();
  const endTime = new Date(endDate).getTime();
  
  // Use faster array method with early initialization for better performance
  const stockData = allStocks[symbol];
  const result = [];
  
  // Manually iterate for better performance than filter
  for (let i = 0; i < stockData.length; i++) {
    const item = stockData[i];
    // Cache date parsing result to avoid repeated conversion
    const itemTime = new Date(item.date).getTime();
    if (itemTime >= startTime && itemTime <= endTime) {
      result.push(item);
    }
  }
  
  // Faster company lookup with direct match instead of find
  let companyName = symbol;
  for (let i = 0; i < COMPANIES.length; i++) {
    if (COMPANIES[i].symbol === symbol) {
      companyName = COMPANIES[i].name;
      break;
    }
  }
  
  console.timeEnd(`Get stock data for ${symbol}`);
  return {
    symbol,
    name: companyName,
    data: result
  };
}

// Get watchlist data (default to top 4 companies) - optimized
export async function getWatchlist(): Promise<StockDataResponse[]> {
  console.time('Get watchlist data');
  const allStocks = await generateSyntheticData();
  const watchlistSymbols = ['AAPL', 'GOOGL', 'AMZN', 'NVDA'];
  
  // Create a map of symbols to company names for faster lookup
  const companyNameMap: Record<string, string> = {};
  for (const company of COMPANIES) {
    companyNameMap[company.symbol] = company.name;
  }
  
  // Process all companies at once for better performance
  const result = watchlistSymbols.map(symbol => {
    if (!allStocks[symbol]) {
      return {
        symbol,
        name: companyNameMap[symbol] || symbol,
        data: []
      };
    }
    
    // Get the most recent 20 days of data instead of 30 for faster processing
    const data = allStocks[symbol].slice(-20);
    
    return {
      symbol,
      name: companyNameMap[symbol] || symbol,
      data
    };
  });
  
  console.timeEnd('Get watchlist data');
  return result;
}

// Get comparison data for multiple companies - optimized
export async function getComparisonData(): Promise<StockDataResponse[]> {
  console.time('Get comparison data');
  const allStocks = await generateSyntheticData();
  const comparisonSymbols = ['AAPL', 'GOOGL', 'AMZN', 'NVDA', 'FB', 'AMD'];
  
  // Create a map of symbols to company names for faster lookup
  const companyNameMap: Record<string, string> = {};
  for (const company of COMPANIES) {
    companyNameMap[company.symbol] = company.name;
  }
  
  // Prepare result array with known size
  const result = new Array(comparisonSymbols.length);
  
  // Sequential processing for more predictable memory usage
  for (let i = 0; i < comparisonSymbols.length; i++) {
    const symbol = comparisonSymbols[i];
    
    if (!allStocks[symbol]) {
      result[i] = {
        symbol,
        name: companyNameMap[symbol] || symbol,
        data: []
      };
      continue;
    }
    
    // Limit to 15 data points for even faster processing and rendering
    const stockData = allStocks[symbol];
    const dataLength = stockData.length;
    const startIndex = Math.max(0, dataLength - 15);
    
    result[i] = {
      symbol,
      name: companyNameMap[symbol] || symbol,
      data: stockData.slice(startIndex)
    };
  }
  
  console.timeEnd('Get comparison data');
  return result;
}
