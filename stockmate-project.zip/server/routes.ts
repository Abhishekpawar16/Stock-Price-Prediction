import express, { type Express, type Request, type Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { 
  stockDataResponseSchema, 
  predictionResponseSchema
} from "@shared/schema";

// In-memory data handlers
import { getStockData, getStockBySymbol, getWatchlist, getComparisonData } from "./stockData";
import { predictStockPrice } from "./stockPredictor";

export async function registerRoutes(app: Express): Promise<Server> {
  const apiRouter = express.Router();
  
  // Get stock data for all companies
  apiRouter.get("/stocks", async (req, res) => {
    try {
      const allStocks = await getStockData();
      const result = Object.keys(allStocks).map(symbol => {
        const company = { symbol };
        return company;
      });
      res.json(result);
    } catch (error) {
      console.error("Error fetching stock data:", error);
      res.status(500).json({ message: "Failed to fetch stock data" });
    }
  });

  // Get stock data for a specific symbol
  apiRouter.get("/stock/:symbol", async (req, res) => {
    try {
      const { symbol } = req.params;
      const startDate = req.query.startDate as string || "2013-01-01";
      const endDate = req.query.endDate as string || "2018-01-01";
      
      const stockData = await getStockBySymbol(symbol, startDate, endDate);
      if (!stockData) {
        return res.status(404).json({ message: `Stock with symbol ${symbol} not found` });
      }
      
      res.json(stockData);
    } catch (error) {
      console.error("Error fetching stock data:", error);
      res.status(500).json({ message: "Failed to fetch stock data" });
    }
  });

  // Get prediction for a specific symbol
  apiRouter.get("/stock/:symbol/predict", async (req, res) => {
    try {
      const { symbol } = req.params;
      const startDate = req.query.startDate as string || "2013-01-01";
      const endDate = req.query.endDate as string || "2018-01-01";
      
      const stockData = await getStockBySymbol(symbol, startDate, endDate);
      if (!stockData) {
        return res.status(404).json({ message: `Stock with symbol ${symbol} not found` });
      }
      
      const prediction = await predictStockPrice(stockData);
      res.json(prediction);
    } catch (error) {
      console.error("Error predicting stock price:", error);
      res.status(500).json({ message: "Failed to predict stock price" });
    }
  });
  
  // Get watchlist stocks with latest data
  apiRouter.get("/stocks/watchlist", async (req, res) => {
    try {
      const watchlistData = await getWatchlist();
      res.json(watchlistData);
    } catch (error) {
      console.error("Error fetching watchlist:", error);
      res.status(500).json({ message: "Failed to fetch watchlist data" });
    }
  });
  
  // Get comparison data for multiple companies
  apiRouter.get("/stocks/comparison", async (req, res) => {
    try {
      const comparisonData = await getComparisonData();
      res.json(comparisonData);
    } catch (error) {
      console.error("Error fetching comparison data:", error);
      res.status(500).json({ message: "Failed to fetch comparison data" });
    }
  });
  
  // Generate a new prediction
  apiRouter.post("/predictions", async (req, res) => {
    try {
      const { symbol, startDate, endDate } = req.body;
      
      if (!symbol) {
        return res.status(400).json({ message: "Symbol is required" });
      }
      
      // Get the stock data to make a prediction
      const stockData = await getStockBySymbol(symbol, startDate, endDate);
      if (!stockData) {
        return res.status(404).json({ message: `Stock data for symbol ${symbol} not found` });
      }
      
      // Generate the prediction
      const prediction = await predictStockPrice(stockData);
      res.json(prediction);
    } catch (error) {
      console.error("Error predicting stock price:", error);
      res.status(500).json({ message: "Failed to predict stock price" });
    }
  });

  // Mount API routes under /api prefix
  app.use("/api", apiRouter);

  const httpServer = createServer(app);
  return httpServer;
}