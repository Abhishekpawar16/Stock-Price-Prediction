import { migrate } from 'drizzle-orm/node-postgres/migrator';
import { db } from './db';
import { seedCompanies } from './services/companyService';
import { closeConnection } from './db';

// Run migrations and seed data
async function setupDatabase() {
  console.log('Setting up database...');
  
  try {
    // Run migrations first
    console.log('Running database migrations...');
    await migrate(db, { migrationsFolder: './migrations' });
    console.log('Migrations completed successfully');
    
    // Seed initial data
    console.log('Seeding initial data...');
    await seedCompanies();
    console.log('Data seeding completed successfully');
    
    return true;
  } catch (error) {
    console.error('Error setting up database:', error);
    return false;
  }
}

// Run as standalone script if called directly
// Using import.meta.url to check if this is the main module in ES Modules
const isMainModule = import.meta.url.endsWith(process.argv[1]);
if (isMainModule) {
  setupDatabase().then(success => {
    if (success) {
      console.log('Database setup completed successfully');
      process.exit(0);
    } else {
      console.error('Database setup failed');
      process.exit(1);
    }
  }).catch(err => {
    console.error('Unexpected error during database setup:', err);
    process.exit(1);
  });
}

// Export for use in other modules
export { setupDatabase };