import { pgTable, text, serial, integer, boolean, timestamp, real, varchar, date, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  firstName: text("first_name"),
  lastName: text("last_name"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  firstName: true,
  lastName: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Companies table to store company information
export const companies = pgTable("companies", {
  id: serial("id").primaryKey(),
  symbol: varchar("symbol", { length: 10 }).notNull().unique(),
  name: varchar("name", { length: 100 }).notNull(),
  description: text("description"),
  industry: varchar("industry", { length: 50 }),
  sector: varchar("sector", { length: 50 }),
  logo: text("logo"),
  website: text("website"),
  ceo: varchar("ceo", { length: 100 }),
  employees: integer("employees"),
  marketCap: decimal("market_cap", { precision: 20, scale: 2 }),
  peRatio: decimal("pe_ratio", { precision: 10, scale: 2 }),
  dividendYield: decimal("dividend_yield", { precision: 10, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertCompanySchema = createInsertSchema(companies).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertCompany = z.infer<typeof insertCompanySchema>;
export type Company = typeof companies.$inferSelect;

// Historical stock data table
export const stockPrices = pgTable("stock_prices", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  date: date("date").notNull(),
  open: decimal("open", { precision: 10, scale: 4 }).notNull(),
  high: decimal("high", { precision: 10, scale: 4 }).notNull(),
  low: decimal("low", { precision: 10, scale: 4 }).notNull(),
  close: decimal("close", { precision: 10, scale: 4 }).notNull(),
  adjustedClose: decimal("adjusted_close", { precision: 10, scale: 4 }),
  volume: integer("volume").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertStockPriceSchema = createInsertSchema(stockPrices).omit({
  id: true,
  createdAt: true,
});

export type InsertStockPrice = z.infer<typeof insertStockPriceSchema>;
export type StockPrice = typeof stockPrices.$inferSelect;

// Stock predictions table
export const predictions = pgTable("predictions", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  predictionDate: date("prediction_date").notNull(),
  predictedPrice: decimal("predicted_price", { precision: 10, scale: 4 }).notNull(),
  actualPrice: decimal("actual_price", { precision: 10, scale: 4 }),
  mse: decimal("mse", { precision: 10, scale: 6 }).notNull(),
  rmse: decimal("rmse", { precision: 10, scale: 6 }).notNull(),
  accuracy: decimal("accuracy", { precision: 10, scale: 2 }).notNull(),
  modelType: varchar("model_type", { length: 50 }).default("LSTM"),
  windowSize: integer("window_size"),
  trainingData: text("training_data"), // JSON string of training data points
  testingData: text("testing_data"),   // JSON string of testing data points
  predictionData: text("prediction_data"), // JSON string of prediction data points
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertPredictionSchema = createInsertSchema(predictions).omit({
  id: true,
  createdAt: true,
});

export type InsertPrediction = z.infer<typeof insertPredictionSchema>;
export type Prediction = typeof predictions.$inferSelect;

// User watchlists table
export const watchlists = pgTable("watchlists", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: varchar("name", { length: 50 }).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertWatchlistSchema = createInsertSchema(watchlists).omit({
  id: true,
  createdAt: true,
});

export type InsertWatchlist = z.infer<typeof insertWatchlistSchema>;
export type Watchlist = typeof watchlists.$inferSelect;

// Watchlist items
export const watchlistItems = pgTable("watchlist_items", {
  id: serial("id").primaryKey(),
  watchlistId: integer("watchlist_id").notNull().references(() => watchlists.id),
  companyId: integer("company_id").notNull().references(() => companies.id),
  addedAt: timestamp("added_at").defaultNow(),
});

export const insertWatchlistItemSchema = createInsertSchema(watchlistItems).omit({
  id: true,
  addedAt: true,
});

export type InsertWatchlistItem = z.infer<typeof insertWatchlistItemSchema>;
export type WatchlistItem = typeof watchlistItems.$inferSelect;

// For API responses
export const stockDataResponseSchema = z.object({
  symbol: z.string(),
  name: z.string(),
  data: z.array(z.object({
    date: z.string(),
    open: z.number(),
    high: z.number(),
    low: z.number(),
    close: z.number(),
    volume: z.number(),
  })),
});

export type StockDataResponse = z.infer<typeof stockDataResponseSchema>;

export const predictionResponseSchema = z.object({
  symbol: z.string(),
  name: z.string(),
  currentPrice: z.number(),
  changePercent: z.number(),
  trainingData: z.array(z.object({
    date: z.string(),
    value: z.number()
  })),
  testingData: z.array(z.object({
    date: z.string(),
    value: z.number()
  })),
  predictions: z.array(z.object({
    date: z.string(),
    value: z.number()
  })),
  metrics: z.object({
    mse: z.number(),
    rmse: z.number(),
    accuracy: z.number()
  })
});

export type PredictionResponse = z.infer<typeof predictionResponseSchema>;
