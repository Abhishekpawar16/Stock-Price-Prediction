import { COMPANIES } from "./constants";
import { Company, DateRange } from "@/types";
import { format, parseISO } from "date-fns";

// Format date to display format
export const formatDate = (dateString: string): string => {
  const date = parseISO(dateString);
  return format(date, "MMM d, yyyy");
};

// Format date for chart display
export const formatChartDate = (dateString: string): string => {
  const date = parseISO(dateString);
  return format(date, "MMM d");
};

// Format number as currency
export const formatCurrency = (value: number): string => {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2
  }).format(value);
};

// Format number as percentage
export const formatPercentage = (value: number): string => {
  return new Intl.NumberFormat("en-US", {
    style: "percent",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(value / 100);
};

// Format large numbers (K, M, B)
export const formatLargeNumber = (value: number): string => {
  if (value >= 1000000000) {
    return (value / 1000000000).toFixed(1) + "B";
  }
  if (value >= 1000000) {
    return (value / 1000000).toFixed(1) + "M";
  }
  if (value >= 1000) {
    return (value / 1000).toFixed(1) + "K";
  }
  return value.toString();
};

// Get company by symbol
export const getCompanyBySymbol = (symbol: string): Company | undefined => {
  return COMPANIES.find(company => company.symbol === symbol);
};

// Get company name by symbol
export const getCompanyName = (symbol: string): string => {
  const company = getCompanyBySymbol(symbol);
  return company ? company.name : symbol;
};

// Format ISO date string to YYYY-MM-DD
export const formatISODateToYYYYMMDD = (isoDateString: string): string => {
  const date = new Date(isoDateString);
  return date.toISOString().split("T")[0];
};

// Create date range query string
export const createDateRangeQuery = (dateRange: DateRange): string => {
  return `startDate=${dateRange.startDate}&endDate=${dateRange.endDate}`;
};
