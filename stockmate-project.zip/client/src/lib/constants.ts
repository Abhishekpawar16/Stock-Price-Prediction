import { Company } from "@/types";

// List of companies with their symbols and names
export const COMPANIES: Company[] = [
  { symbol: "AAPL", name: "Apple" },
  { symbol: "GOOGL", name: "Google" },
  { symbol: "AMZN", name: "Amazon" },
  { symbol: "NVDA", name: "NVIDIA" },
  { symbol: "FB", name: "Facebook" },
  { symbol: "AMD", name: "AMD" },
  { symbol: "EBAY", name: "eBay" },
  { symbol: "CSCO", name: "Cisco" },
  { symbol: "IBM", name: "IBM" }
];

// Chart colors
export const CHART_COLORS = {
  training: "#10b981", // success/green
  actual: "#2463EB", // primary blue
  predicted: "#ef4444", // danger/red
  volume: "rgba(79, 70, 229, 0.6)", // purple
  open: "#60a5fa", // light blue
  close: "#f97316", // orange
};

// Default date range for stock data
export const DEFAULT_DATE_RANGE = {
  startDate: "2013-01-01",
  endDate: "2018-01-01"
};

// Chart time range options
export const TIME_RANGES = [
  { label: "30 Days", value: 30 },
  { label: "90 Days", value: 90 },
  { label: "180 Days", value: 180 },
  { label: "1 Year", value: 365 },
  { label: "All", value: "all" }
];

// Default prediction window (days)
export const DEFAULT_PREDICTION_WINDOW = 60;

// Animation settings
export const ANIMATION = {
  duration: 0.5,
  staggerChildren: 0.1,
  slideDistance: 20
};

// Default layout settings
export const LAYOUT = {
  sidebar: {
    width: 64,
    expandedWidth: 240
  }
};
