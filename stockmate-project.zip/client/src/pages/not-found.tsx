import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";
import Logo from "@/components/Logo";
import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gray-50">
      <Card className="w-full max-w-md mx-4">
        <CardContent className="pt-6">
          <div className="flex items-center justify-center mb-6">
            <Logo size={50} />
            <h2 className="text-2xl font-bold text-primary-600 ml-3">StockMate</h2>
          </div>
          
          <div className="flex mb-4 gap-2">
            <AlertCircle className="h-8 w-8 text-red-500" />
            <h1 className="text-2xl font-bold text-gray-900">404 Page Not Found</h1>
          </div>

          <p className="mt-4 text-sm text-gray-600">
            Sorry, the page you are looking for doesn't exist.
          </p>
          
          <div className="mt-6 text-center">
            <Link href="/">
              <button className="inline-flex items-center justify-center px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-md hover:bg-primary-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-primary-500">
                Return to Dashboard
              </button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
