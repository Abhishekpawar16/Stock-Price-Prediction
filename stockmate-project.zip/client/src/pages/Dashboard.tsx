import { useState } from "react";
import StockDashboard from "@/components/StockDashboard";
import { DateRange } from "@/types";
import { DEFAULT_DATE_RANGE } from "@/lib/constants";

export default function Dashboard() {
  const [selectedSymbol, setSelectedSymbol] = useState<string>("AAPL");
  const [dateRange, setDateRange] = useState<DateRange>(DEFAULT_DATE_RANGE);

  return (
    <StockDashboard
      selectedSymbol={selectedSymbol}
      setSelectedSymbol={setSelectedSymbol}
      dateRange={dateRange}
      setDateRange={setDateRange}
    />
  );
}
