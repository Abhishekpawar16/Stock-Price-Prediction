import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/Sidebar";
import StockSelectionForm from "@/components/StockSelectionForm";
import MetricsOverview from "@/components/MetricsOverview";
import MainChart from "@/components/charts/MainChart";
import VolumeChart from "@/components/charts/VolumeChart";
import PriceComparisonChart from "@/components/charts/PriceComparisonChart";
import CompanyComparisonChart from "@/components/charts/CompanyComparisonChart";
import { DateRange, StockPrediction } from "@/types";
import { createDateRangeQuery } from "@/lib/stockUtils";
import { TIME_RANGES } from "@/lib/constants";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

interface StockDashboardProps {
  selectedSymbol: string;
  setSelectedSymbol: (symbol: string) => void;
  dateRange: DateRange;
  setDateRange: (dateRange: DateRange) => void;
}

export default function StockDashboard({
  selectedSymbol,
  setSelectedSymbol,
  dateRange,
  setDateRange
}: StockDashboardProps) {
  const [timeRange, setTimeRange] = useState<number | string>(30);
  const { toast } = useToast();

  const { data: predictionData, isLoading: isPredictionLoading, refetch } = useQuery<StockPrediction>({
    queryKey: [`/api/stock/${selectedSymbol}/predict?${createDateRangeQuery(dateRange)}`],
    refetchOnWindowFocus: false,
  });

  const handleAnalyze = async () => {
    try {
      toast({
        title: "Analyzing Stock Data",
        description: `Analyzing ${selectedSymbol} stock data. This may take a moment...`,
      });
      
      await refetch();
      
      toast({
        title: "Analysis Complete",
        description: `Successfully analyzed ${selectedSymbol} stock data`,
      });
    } catch (error) {
      toast({
        title: "Analysis Failed",
        description: "Failed to analyze stock data. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleTimeRangeChange = (range: number | string) => {
    setTimeRange(range);
  };

  const containerAnimation = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemAnimation = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-gray-50">
      <Sidebar 
        selectedSymbol={selectedSymbol}
        setSelectedSymbol={setSelectedSymbol}
      />

      <main className="flex-1 overflow-x-hidden">
        {/* Top bar */}
        <div className="bg-white shadow-sm border-b border-gray-200">
          <div className="px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
            <div className="flex items-center">
              <h2 className="text-xl font-semibold text-secondary-800">
                StockMate Predictions Dashboard
              </h2>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Dark mode toggle - functionality could be added later */}
              <button className="p-2 rounded-full text-secondary-600 hover:bg-secondary-100 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg>
              </button>
              
              {/* User profile */}
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-600 mr-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                </div>
                <span className="text-sm font-medium hidden sm:inline-block">User</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Dashboard content */}
        <motion.div 
          className="px-4 py-6 sm:px-6 lg:px-8"
          variants={containerAnimation}
          initial="hidden"
          animate="visible"
        >
          <motion.div variants={itemAnimation}>
            <StockSelectionForm
              selectedSymbol={selectedSymbol}
              setSelectedSymbol={setSelectedSymbol}
              dateRange={dateRange}
              setDateRange={setDateRange}
              onAnalyze={handleAnalyze}
            />
          </motion.div>
          
          <motion.div variants={itemAnimation}>
            <MetricsOverview predictionData={predictionData} isLoading={isPredictionLoading} />
          </motion.div>
          
          <motion.div variants={itemAnimation}>
            <MainChart 
              predictionData={predictionData}
              isLoading={isPredictionLoading}
              timeRange={timeRange}
              onTimeRangeChange={handleTimeRangeChange}
              timeRangeOptions={TIME_RANGES}
            />
          </motion.div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <motion.div variants={itemAnimation}>
              <VolumeChart 
                symbol={selectedSymbol}
                dateRange={dateRange}
                isLoading={isPredictionLoading}
              />
            </motion.div>
            
            <motion.div variants={itemAnimation}>
              <PriceComparisonChart 
                symbol={selectedSymbol}
                dateRange={dateRange}
                isLoading={isPredictionLoading}
              />
            </motion.div>
          </div>
          
          <motion.div variants={itemAnimation}>
            <CompanyComparisonChart isLoading={isPredictionLoading} />
          </motion.div>
        </motion.div>
      </main>
    </div>
  );
}
