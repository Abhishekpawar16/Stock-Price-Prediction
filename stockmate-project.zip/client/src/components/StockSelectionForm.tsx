import { useState } from "react";
import { COMPANIES } from "@/lib/constants";
import { DateRange } from "@/types";
import { motion } from "framer-motion";
import { 
  Card,
  CardContent,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface StockSelectionFormProps {
  selectedSymbol: string;
  setSelectedSymbol: (symbol: string) => void;
  dateRange: DateRange;
  setDateRange: (dateRange: DateRange) => void;
  onAnalyze: () => void;
}

export default function StockSelectionForm({
  selectedSymbol,
  setSelectedSymbol,
  dateRange,
  setDateRange,
  onAnalyze
}: StockSelectionFormProps) {
  const [isLoading, setIsLoading] = useState(false);

  const handleSymbolChange = (value: string) => {
    setSelectedSymbol(value);
  };

  const handleStartDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setDateRange({ ...dateRange, startDate: e.target.value });
  };

  const handleEndDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setDateRange({ ...dateRange, endDate: e.target.value });
  };

  const handleAnalyze = async () => {
    setIsLoading(true);
    try {
      await onAnalyze();
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="mb-6">
        <CardContent className="pt-6">
          <h3 className="text-lg font-semibold mb-4">Stock Selection</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="stockSelect" className="block text-sm font-medium text-secondary-700 mb-1">
                Select Company
              </Label>
              <Select value={selectedSymbol} onValueChange={handleSymbolChange}>
                <SelectTrigger id="stockSelect" className="w-full">
                  <SelectValue placeholder="Select a company" />
                </SelectTrigger>
                <SelectContent>
                  {COMPANIES.map((company) => (
                    <SelectItem key={company.symbol} value={company.symbol}>
                      {company.name} ({company.symbol})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="dateRangeStart" className="block text-sm font-medium text-secondary-700 mb-1">
                Date Range Start
              </Label>
              <input
                type="date"
                id="dateRangeStart"
                value={dateRange.startDate}
                onChange={handleStartDateChange}
                className="block w-full rounded-lg border-secondary-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 py-3 px-4 text-secondary-900"
              />
            </div>
            
            <div>
              <Label htmlFor="dateRangeEnd" className="block text-sm font-medium text-secondary-700 mb-1">
                Date Range End
              </Label>
              <input
                type="date"
                id="dateRangeEnd"
                value={dateRange.endDate}
                onChange={handleEndDateChange}
                className="block w-full rounded-lg border-secondary-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 py-3 px-4 text-secondary-900"
              />
            </div>
          </div>
          
          <div className="mt-4 flex justify-end">
            <Button
              onClick={handleAnalyze}
              disabled={isLoading}
              className="inline-flex items-center px-6 py-2.5"
            >
              {isLoading ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Analyzing...
                </>
              ) : (
                <>
                  <svg xmlns="http://www.w3.org/2000/svg" className="mr-2" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>
                  Analyze Stock
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
