import { motion } from "framer-motion";
import { StockPrediction } from "@/types";
import { formatCurrency } from "@/lib/stockUtils";
import { Skeleton } from "@/components/ui/skeleton";

interface MetricsOverviewProps {
  predictionData: StockPrediction | undefined;
  isLoading: boolean;
}

export default function MetricsOverview({ predictionData, isLoading }: MetricsOverviewProps) {
  const metrics = [
    {
      title: "Current Price",
      value: predictionData ? formatCurrency(predictionData.currentPrice) : "$187.34",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"/><path d="M12 18V6"/></svg>
      ),
      iconBg: "bg-green-100 text-green-600",
      changeElement: predictionData && (
        <div className="mt-3 flex items-center text-sm">
          <span className={`font-medium ${predictionData.changePercent >= 0 ? 'text-success' : 'text-danger'}`}>
            <svg xmlns="http://www.w3.org/2000/svg" className="inline-block mr-1 h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              {predictionData.changePercent >= 0 ? <polyline points="18 15 12 9 6 15"/> : <polyline points="6 9 12 15 18 9"/>}
            </svg>
            {Math.abs(predictionData.changePercent).toFixed(2)}%
          </span>
          <span className="text-secondary-500 ml-2">Today</span>
        </div>
      )
    },
    {
      title: "Prediction Accuracy",
      value: predictionData ? `${predictionData.metrics.accuracy.toFixed(1)}%` : "94.6%",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>
      ),
      iconBg: "bg-blue-100 text-blue-600",
      changeElement: (
        <div className="mt-3 flex items-center text-sm">
          <span className="text-secondary-500">Based on historical data</span>
        </div>
      )
    },
    {
      title: "MSE",
      value: predictionData ? predictionData.metrics.mse.toFixed(4) : "9.1235",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 3v18h18"/><path d="M13 17V9"/><path d="M18 17V5"/><path d="M8 17v-3"/></svg>
      ),
      iconBg: "bg-red-100 text-red-600",
      changeElement: (
        <div className="mt-3 flex items-center text-sm">
          <span className="text-secondary-500">Mean Squared Error</span>
        </div>
      )
    },
    {
      title: "RMSE",
      value: predictionData ? predictionData.metrics.rmse.toFixed(4) : "3.0205",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="12 2 19.6 6.5 19.6 17.5 12 22 4.4 17.5 4.4 6.5"/></svg>
      ),
      iconBg: "bg-purple-100 text-purple-600",
      changeElement: (
        <div className="mt-3 flex items-center text-sm">
          <span className="text-secondary-500">Root Mean Squared Error</span>
        </div>
      )
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {metrics.map((metric, index) => (
        <motion.div
          key={metric.title}
          className="bg-white rounded-lg shadow-md p-5 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: index * 0.1 }}
        >
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-secondary-500 font-medium">{metric.title}</p>
              {isLoading ? (
                <Skeleton className="h-8 w-24 mt-1" />
              ) : (
                <h4 className="text-2xl font-bold text-secondary-900 mt-1">{metric.value}</h4>
              )}
            </div>
            <div className={`rounded-full p-2 ${metric.iconBg}`}>
              {metric.icon}
            </div>
          </div>
          {!isLoading && metric.changeElement}
        </motion.div>
      ))}
    </div>
  );
}
