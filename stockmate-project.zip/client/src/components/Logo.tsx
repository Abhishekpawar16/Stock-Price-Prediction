import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
}

export default function Logo({ className = "", size = 40 }: LogoProps) {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 100 100" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg" 
      className={className}
    >
      {/* Circle background */}
      <circle cx="50" cy="50" r="50" fill="url(#gradient)" />
      
      {/* Stock chart line */}
      <path 
        d="M20 70 L35 55 L50 65 L65 40 L80 30" 
        stroke="white" 
        strokeWidth="4" 
        strokeLinecap="round" 
        strokeLinejoin="round"
      />
      
      {/* Small circles at data points */}
      <circle cx="20" cy="70" r="3" fill="white" />
      <circle cx="35" cy="55" r="3" fill="white" />
      <circle cx="50" cy="65" r="3" fill="white" />
      <circle cx="65" cy="40" r="3" fill="white" />
      <circle cx="80" cy="30" r="3" fill="white" />
      
      {/* Gradient definition */}
      <defs>
        <linearGradient id="gradient" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
          <stop stopColor="#4F46E5" />
          <stop offset="1" stopColor="#7C3AED" />
        </linearGradient>
      </defs>
    </svg>
  );
}