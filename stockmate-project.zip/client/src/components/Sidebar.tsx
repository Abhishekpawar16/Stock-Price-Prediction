import { useState } from "react";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { StockDataResponse } from "@shared/schema";
import { formatPercentage } from "@/lib/stockUtils";
import Logo from "./Logo";

interface SidebarProps {
  selectedSymbol: string;
  setSelectedSymbol: (symbol: string) => void;
}

export default function Sidebar({ selectedSymbol, setSelectedSymbol }: SidebarProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const { data: watchlistData } = useQuery<StockDataResponse[]>({
    queryKey: ['/api/stocks/watchlist'],
    refetchInterval: 60000, // Refetch every minute
  });

  // Toggle mobile menu
  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  // Handle stock selection
  const handleStockSelect = (symbol: string) => {
    setSelectedSymbol(symbol);
    setIsMobileMenuOpen(false);
  };

  // Get stock price change percentage
  const getStockChange = (symbol: string): { value: number, isPositive: boolean } => {
    if (!watchlistData) {
      return { value: 0, isPositive: true };
    }
    
    const stockData = watchlistData.find(stock => stock.symbol === symbol);
    if (!stockData || stockData.data.length < 2) {
      return { value: 0, isPositive: true };
    }
    
    const latestPrice = stockData.data[stockData.data.length - 1].close;
    const previousPrice = stockData.data[stockData.data.length - 2].close;
    const changePercent = ((latestPrice - previousPrice) / previousPrice) * 100;
    
    return {
      value: Math.abs(changePercent),
      isPositive: changePercent >= 0
    };
  };

  // Default watchlist if data isn't loaded yet
  const defaultWatchlist = [
    { symbol: "AAPL", name: "Apple", change: { value: 1.42, isPositive: true } },
    { symbol: "GOOGL", name: "Google", change: { value: 0.87, isPositive: false } },
    { symbol: "AMZN", name: "Amazon", change: { value: 2.31, isPositive: true } },
    { symbol: "NVDA", name: "NVIDIA", change: { value: 3.75, isPositive: true } },
  ];

  // Use actual data if available, otherwise use default
  const watchlist = watchlistData 
    ? watchlistData.map(stock => ({
        symbol: stock.symbol,
        name: stock.name,
        change: getStockChange(stock.symbol)
      }))
    : defaultWatchlist;

  return (
    <aside className="w-full md:w-64 bg-white shadow-md md:min-h-screen z-10">
      <div className="p-4 flex items-center justify-between md:justify-start border-b border-gray-200">
        <div className="flex items-center">
          <Logo size={36} className="mr-3" />
          <h1 className="text-xl font-bold text-primary-600">StockMate</h1>
        </div>
        <button 
          className="md:hidden text-gray-600"
          onClick={toggleMobileMenu}
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
        </button>
      </div>
      
      <nav className={`p-4 ${isMobileMenuOpen ? 'block' : 'hidden'} md:block`}>
        <div className="space-y-1">
          <a href="#" className="flex items-center px-4 py-3 text-primary-600 bg-primary-50 rounded-lg">
            <svg xmlns="http://www.w3.org/2000/svg" className="mr-3" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
            <span>Dashboard</span>
          </a>
          <a href="#" className="flex items-center px-4 py-3 text-secondary-600 hover:bg-primary-50 rounded-lg transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className="mr-3" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>
            <span>Stock Analysis</span>
          </a>
          <a href="#" className="flex items-center px-4 py-3 text-secondary-600 hover:bg-primary-50 rounded-lg transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className="mr-3" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/></svg>
            <span>AI Predictions</span>
          </a>
          <a href="#" className="flex items-center px-4 py-3 text-secondary-600 hover:bg-primary-50 rounded-lg transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className="mr-3" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>
            <span>Settings</span>
          </a>
        </div>
        
        <div className="mt-8">
          <h3 className="px-4 text-xs font-semibold text-secondary-500 uppercase tracking-wider">Watchlist</h3>
          <div className="mt-3 space-y-1">
            {watchlist.map((stock) => (
              <motion.a
                key={stock.symbol}
                href="#"
                className={`flex items-center justify-between px-4 py-2 text-sm ${
                  selectedSymbol === stock.symbol 
                    ? 'bg-primary-50 text-primary-600' 
                    : 'text-secondary-600 hover:bg-primary-50'
                } rounded-lg transition-colors`}
                onClick={() => handleStockSelect(stock.symbol)}
                whileHover={{ y: -2 }}
                transition={{ duration: 0.2 }}
              >
                <div className="flex items-center">
                  <span className="w-6 h-6 flex items-center justify-center rounded-full bg-primary-100 text-primary-600 mr-2 text-xs">
                    {stock.symbol.charAt(0)}
                  </span>
                  <span>{stock.symbol}</span>
                </div>
                <span className={`font-medium ${stock.change.isPositive ? 'text-success' : 'text-danger'}`}>
                  {stock.change.isPositive ? '+' : '-'}{formatPercentage(stock.change.value)}
                </span>
              </motion.a>
            ))}
          </div>
        </div>
      </nav>
    </aside>
  );
}
