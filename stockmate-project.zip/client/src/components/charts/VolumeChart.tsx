import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { StockDataResponse } from "@shared/schema";
import { DateRange, VolumeDataPoint } from "@/types";
import { CHART_COLORS } from "@/lib/constants";
import { formatChartDate, formatLargeNumber, createDateRangeQuery } from "@/lib/stockUtils";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from "recharts";

interface VolumeChartProps {
  symbol: string;
  dateRange: DateRange;
  isLoading: boolean;
}

export default function VolumeChart({ 
  symbol, 
  dateRange,
  isLoading 
}: VolumeChartProps) {
  const { data: stockData } = useQuery<StockDataResponse>({
    queryKey: [`/api/stock/${symbol}?${createDateRangeQuery(dateRange)}`],
    enabled: !isLoading,
  });

  // Process data for chart
  const volumeData: VolumeDataPoint[] = stockData?.data
    ? stockData.data.slice(-30).map(item => ({
        date: formatChartDate(item.date),
        volume: item.volume
      }))
    : [];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="h-full">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold mb-4">Trading Volume</h3>
          
          <div className="h-[300px]">
            {!stockData || volumeData.length === 0 ? (
              <div className="h-full w-full flex items-center justify-center">
                {isLoading ? (
                  <div className="w-8 h-8 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin"></div>
                ) : (
                  <p className="text-secondary-500">No volume data available</p>
                )}
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={volumeData}
                  margin={{ top: 10, right: 10, left: 10, bottom: 30 }}
                >
                  <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 12 }}
                    tickCount={7}
                    angle={-45}
                    textAnchor="end"
                    height={50}
                  />
                  <YAxis 
                    tickFormatter={(value) => formatLargeNumber(value)}
                    tick={{ fontSize: 12 }}
                  />
                  <Tooltip
                    formatter={(value: number) => [new Intl.NumberFormat().format(value), "Volume"]}
                    labelFormatter={(label) => `Date: ${label}`}
                    contentStyle={{ 
                      backgroundColor: "white", 
                      border: "1px solid #e2e8f0",
                      borderRadius: "0.5rem",
                      padding: "0.5rem"
                    }}
                  />
                  <Bar 
                    dataKey="volume" 
                    fill={CHART_COLORS.volume}
                    animationDuration={1500}
                    animationBegin={300}
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
