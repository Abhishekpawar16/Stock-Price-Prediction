import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { StockPrediction } from "@/types";
import { CHART_COLORS } from "@/lib/constants";
import { formatChartDate, formatCurrency } from "@/lib/stockUtils";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  Legend,
  ReferenceLine
} from "recharts";

interface MainChartProps {
  predictionData: StockPrediction | undefined;
  isLoading: boolean;
  timeRange: number | string;
  onTimeRangeChange: (range: number | string) => void;
  timeRangeOptions: { label: string; value: number | string }[];
}

export default function MainChart({
  predictionData,
  isLoading,
  timeRange,
  onTimeRangeChange,
  timeRangeOptions
}: MainChartProps) {
  const [chartData, setChartData] = useState<any[]>([]);
  const chartRef = useRef<HTMLDivElement>(null);

  // Prepare chart data when prediction data changes
  useEffect(() => {
    if (!predictionData) return;

    const allDates = new Set<string>();
    
    // Add all dates from the three datasets
    predictionData.trainingData.forEach(item => allDates.add(item.date));
    predictionData.testingData.forEach(item => allDates.add(item.date));
    predictionData.predictions.forEach(item => allDates.add(item.date));
    
    // Sort dates chronologically
    const sortedDates = Array.from(allDates).sort((a, b) => new Date(a).getTime() - new Date(b).getTime());
    
    // Determine the date cutoff based on timeRange
    let filteredDates = sortedDates;
    if (timeRange !== 'all' && typeof timeRange === 'number') {
      const cutoffIndex = Math.max(0, sortedDates.length - timeRange);
      filteredDates = sortedDates.slice(cutoffIndex);
    }
    
    // Create merged dataset
    const mergedData = filteredDates.map(date => {
      const trainingPoint = predictionData.trainingData.find(item => item.date === date);
      const testingPoint = predictionData.testingData.find(item => item.date === date);
      const predictionPoint = predictionData.predictions.find(item => item.date === date);
      
      return {
        date,
        formattedDate: formatChartDate(date),
        training: trainingPoint?.value || null,
        actual: testingPoint?.value || null,
        predicted: predictionPoint?.value || null
      };
    });
    
    setChartData(mergedData);
  }, [predictionData, timeRange]);

  const handleTimeRangeClick = (range: number | string) => {
    onTimeRangeChange(range);
  };

  // Find the separation line between training and testing data
  const separationDate = predictionData?.trainingData.length 
    ? predictionData.trainingData[predictionData.trainingData.length - 1].date 
    : '';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="mb-6"
    >
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-wrap items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Stock Price Prediction</h3>
            
            <div className="flex space-x-2 mt-2 sm:mt-0">
              {timeRangeOptions.map((option) => (
                <Button
                  key={option.value.toString()}
                  variant={timeRange === option.value ? "default" : "outline"}
                  size="sm"
                  onClick={() => handleTimeRangeClick(option.value)}
                >
                  {option.label}
                </Button>
              ))}
            </div>
          </div>
          
          <div ref={chartRef} className="relative h-[400px] w-full">
            {isLoading ? (
              <div className="absolute inset-0 flex items-center justify-center bg-white bg-opacity-80 z-10">
                <div className="w-10 h-10 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin"></div>
              </div>
            ) : !predictionData ? (
              <div className="h-full w-full flex items-center justify-center">
                <p className="text-secondary-500">No data available. Please select a stock and analyze.</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={chartData}
                  margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                  <XAxis 
                    dataKey="formattedDate" 
                    tickMargin={10}
                    tick={{ fontSize: 12 }}
                    tickCount={10}
                  />
                  <YAxis 
                    tickFormatter={(value) => `$${value}`}
                    tick={{ fontSize: 12 }}
                    domain={['dataMin - 5', 'dataMax + 5']}
                  />
                  <Tooltip
                    content={({ active, payload, label }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="bg-white p-3 shadow-lg rounded-md border border-gray-200">
                            <p className="font-medium">{payload[0]?.payload.date}</p>
                            {payload.map((entry, index) => (
                              entry.value !== null && (
                                <p key={index} className="text-sm" style={{ color: entry.color }}>
                                  {entry.name}: {formatCurrency(entry.value as number)}
                                </p>
                              )
                            ))}
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Legend 
                    verticalAlign="bottom" 
                    height={36}
                    wrapperStyle={{ paddingTop: '20px' }}
                  />
                  <defs>
                    <linearGradient id="trainingGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={CHART_COLORS.training} stopOpacity={0.3} />
                      <stop offset="95%" stopColor={CHART_COLORS.training} stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="actualGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={CHART_COLORS.actual} stopOpacity={0.3} />
                      <stop offset="95%" stopColor={CHART_COLORS.actual} stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="predictedGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={CHART_COLORS.predicted} stopOpacity={0.3} />
                      <stop offset="95%" stopColor={CHART_COLORS.predicted} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  
                  <Area
                    type="monotone"
                    dataKey="training"
                    name="Training Data"
                    stroke={CHART_COLORS.training}
                    fillOpacity={1}
                    fill="url(#trainingGradient)"
                    animationDuration={1000}
                    activeDot={{ r: 4 }}
                  />
                  <Area
                    type="monotone"
                    dataKey="actual"
                    name="Actual Price"
                    stroke={CHART_COLORS.actual}
                    fillOpacity={1}
                    fill="url(#actualGradient)"
                    animationDuration={1000}
                    animationBegin={300}
                    activeDot={{ r: 4 }}
                  />
                  <Area
                    type="monotone"
                    dataKey="predicted"
                    name="Predicted Price"
                    stroke={CHART_COLORS.predicted}
                    fillOpacity={1}
                    fill="url(#predictedGradient)"
                    strokeDasharray="5 5"
                    animationDuration={1000}
                    animationBegin={600}
                    activeDot={{ r: 4 }}
                  />
                  
                  {separationDate && (
                    <ReferenceLine 
                      x={formatChartDate(separationDate)} 
                      stroke="#888" 
                      strokeDasharray="3 3"
                      label={{ 
                        value: "Train/Test Split", 
                        position: "top",
                        fill: "#888",
                        fontSize: 12
                      }} 
                    />
                  )}
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
          
          <div className="mt-4 flex flex-wrap items-center justify-center space-x-4">
            <div className="flex items-center">
              <span className="w-3 h-3 rounded-full" style={{ backgroundColor: CHART_COLORS.training }} />
              <span className="text-sm text-secondary-600 ml-2">Training Data</span>
            </div>
            <div className="flex items-center">
              <span className="w-3 h-3 rounded-full" style={{ backgroundColor: CHART_COLORS.actual }} />
              <span className="text-sm text-secondary-600 ml-2">Actual Price</span>
            </div>
            <div className="flex items-center">
              <span className="w-3 h-3 rounded-full" style={{ backgroundColor: CHART_COLORS.predicted }} />
              <span className="text-sm text-secondary-600 ml-2">Predicted Price</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
