import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { StockDataResponse } from "@shared/schema";
import { CompanyComparisonData } from "@/types";
import { COMPANIES } from "@/lib/constants";
import { formatCurrency } from "@/lib/stockUtils";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
} from "recharts";

interface CompanyComparisonChartProps {
  isLoading: boolean;
}

export default function CompanyComparisonChart({ isLoading }: CompanyComparisonChartProps) {
  const { data: companyDataList } = useQuery<StockDataResponse[]>({
    queryKey: ['/api/stocks/comparison'],
    enabled: !isLoading,
  });

  // Process data for company comparison
  const comparisonData: CompanyComparisonData[] = companyDataList 
    ? companyDataList.map(stock => {
        const data = stock.data;
        const latestPrice = data[data.length - 1].close;
        const previousPrice = data[data.length - 2]?.close || latestPrice;
        const changePercent = ((latestPrice - previousPrice) / previousPrice) * 100;
        
        return {
          symbol: stock.symbol,
          name: stock.name,
          currentPrice: latestPrice,
          changePercent: changePercent,
          chartData: data.slice(-20).map(item => ({
            date: item.date,
            value: item.close
          }))
        };
      })
    : [];

  // If we don't have data yet, use a placeholder with the first 3 companies
  const displayData = comparisonData.length > 0 
    ? comparisonData.slice(0, 3) 
    : COMPANIES.slice(0, 3).map(company => ({
        symbol: company.symbol,
        name: company.name,
        currentPrice: 0,
        changePercent: 0,
        chartData: []
      }));

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="mt-6 mb-6"
    >
      <Card>
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold mb-4">Company Comparison</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {displayData.map((company, index) => (
              <motion.div
                key={company.symbol}
                className="border border-secondary-200 rounded-lg p-4 hover:shadow-md transition-all"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.1 * index }}
                whileHover={{ y: -5 }}
              >
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-medium">{company.symbol}</h4>
                  {!isLoading && (
                    <span className={`text-sm font-medium ${company.changePercent >= 0 ? 'text-success' : 'text-danger'}`}>
                      {company.changePercent >= 0 ? '+' : ''}{company.changePercent.toFixed(2)}%
                    </span>
                  )}
                </div>
                
                <div className="h-24">
                  {isLoading ? (
                    <div className="h-full w-full flex items-center justify-center">
                      <div className="w-6 h-6 border-2 border-primary-200 border-t-primary-600 rounded-full animate-spin"></div>
                    </div>
                  ) : company.chartData.length === 0 ? (
                    <div className="h-full w-full flex items-center justify-center">
                      <p className="text-sm text-secondary-500">No data available</p>
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={company.chartData}>
                        <Line
                          type="monotone"
                          dataKey="value"
                          stroke={company.changePercent >= 0 ? "#10b981" : "#ef4444"}
                          strokeWidth={2}
                          dot={false}
                          animationDuration={1000}
                        />
                        <XAxis dataKey="date" hide={true} />
                        <YAxis hide={true} domain={['dataMin - 5', 'dataMax + 5']} />
                      </LineChart>
                    </ResponsiveContainer>
                  )}
                </div>
                
                <div className="text-center mt-3">
                  {isLoading ? (
                    <div className="h-6 w-20 bg-gray-200 rounded animate-pulse mx-auto"></div>
                  ) : (
                    <span className="text-lg font-bold">{formatCurrency(company.currentPrice)}</span>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
