import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { StockDataResponse } from "@shared/schema";
import { DateRange, PriceComparisonPoint } from "@/types";
import { CHART_COLORS } from "@/lib/constants";
import { formatChartDate, formatCurrency, createDateRangeQuery } from "@/lib/stockUtils";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";

interface PriceComparisonChartProps {
  symbol: string;
  dateRange: DateRange;
  isLoading: boolean;
}

export default function PriceComparisonChart({ 
  symbol, 
  dateRange,
  isLoading
}: PriceComparisonChartProps) {
  const { data: stockData } = useQuery<StockDataResponse>({
    queryKey: [`/api/stock/${symbol}?${createDateRangeQuery(dateRange)}`],
    enabled: !isLoading,
  });

  // Process data for chart
  const priceData: PriceComparisonPoint[] = stockData?.data
    ? stockData.data.slice(-30).map(item => ({
        date: formatChartDate(item.date),
        open: item.open,
        close: item.close
      }))
    : [];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="h-full">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold mb-4">Open vs Close Price</h3>
          
          <div className="h-[300px]">
            {!stockData || priceData.length === 0 ? (
              <div className="h-full w-full flex items-center justify-center">
                {isLoading ? (
                  <div className="w-8 h-8 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin"></div>
                ) : (
                  <p className="text-secondary-500">No price comparison data available</p>
                )}
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={priceData}
                  margin={{ top: 10, right: 10, left: 10, bottom: 30 }}
                >
                  <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 12 }}
                    tickCount={7}
                    angle={-45}
                    textAnchor="end"
                    height={50}
                  />
                  <YAxis 
                    tickFormatter={(value) => `$${value}`}
                    domain={['dataMin - 5', 'dataMax + 5']}
                    tick={{ fontSize: 12 }}
                  />
                  <Tooltip
                    formatter={(value: number) => [formatCurrency(value), ""]}
                    labelFormatter={(label) => `Date: ${label}`}
                    contentStyle={{ 
                      backgroundColor: "white", 
                      border: "1px solid #e2e8f0",
                      borderRadius: "0.5rem",
                      padding: "0.5rem"
                    }}
                  />
                  <Legend 
                    verticalAlign="top" 
                    height={36}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="open" 
                    name="Open Price"
                    stroke={CHART_COLORS.open} 
                    dot={false}
                    animationDuration={1500}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="close" 
                    name="Close Price"
                    stroke={CHART_COLORS.close} 
                    dot={false} 
                    animationDuration={1500}
                    animationBegin={300}
                  />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
