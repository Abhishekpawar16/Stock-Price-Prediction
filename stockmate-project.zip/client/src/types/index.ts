export interface StockData {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface Company {
  symbol: string;
  name: string;
  logo?: string;
}

export interface PredictionMetrics {
  mse: number;
  rmse: number;
  accuracy: number;
}

export interface StockPrediction {
  symbol: string;
  name: string;
  currentPrice: number;
  changePercent: number;
  trainingData: { date: string; value: number }[];
  testingData: { date: string; value: number }[];
  predictions: { date: string; value: number }[];
  metrics: PredictionMetrics;
}

export interface ChartDataPoint {
  date: string;
  value: number | null;
}

export interface VolumeDataPoint {
  date: string;
  volume: number;
}

export interface PriceComparisonPoint {
  date: string;
  open: number;
  close: number;
}

export interface CompanyComparisonData {
  symbol: string;
  name: string;
  currentPrice: number;
  changePercent: number;
  chartData: ChartDataPoint[];
}

export interface DateRange {
  startDate: string;
  endDate: string;
}
